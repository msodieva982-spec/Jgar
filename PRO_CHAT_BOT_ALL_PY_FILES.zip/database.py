from datetime import datetime,timezone
from sqlalchemy.ext.asyncio import create_async_engine,async_sessionmaker
from sqlalchemy.orm import DeclarativeBase,Mapped,mapped_column
from sqlalchemy import Integer,BigInteger,String,Text,Boolean,DateTime,UniqueConstraint
from config import settings

class Base(DeclarativeBase): pass
class User(Base):
    __tablename__="users"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    tg_id:Mapped[int]=mapped_column(BigInteger,unique=True,index=True); username:Mapped[str|None]=mapped_column(String(255))
    banned:Mapped[bool]=mapped_column(Boolean,default=False); pro_until:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    referral:Mapped[str|None]=mapped_column(String(100)); referred_by:Mapped[int|None]=mapped_column(BigInteger)
class Admin(Base):
    __tablename__="admins"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    tg_id:Mapped[int]=mapped_column(BigInteger,unique=True); active:Mapped[bool]=mapped_column(Boolean,default=True)
class Permission(Base):
    __tablename__="permissions"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    admin_id:Mapped[int]=mapped_column(Integer); name:Mapped[str]=mapped_column(String(100))
    __table_args__=(UniqueConstraint("admin_id","name"),)
class Feature(Base):
    __tablename__="features"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    name:Mapped[str]=mapped_column(String(100),unique=True); enabled:Mapped[bool]=mapped_column(Boolean,default=True)
class MessageLog(Base):
    __tablename__="message_logs"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    owner_id:Mapped[int]=mapped_column(BigInteger); chat_id:Mapped[int]=mapped_column(BigInteger)
    message_id:Mapped[int]=mapped_column(BigInteger); kind:Mapped[str]=mapped_column(String(30))
    text:Mapped[str|None]=mapped_column(Text); deleted:Mapped[bool]=mapped_column(Boolean,default=False); edited:Mapped[bool]=mapped_column(Boolean,default=False)
class ChatMemory(Base):
    __tablename__="chat_memory"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    owner_id:Mapped[int]=mapped_column(BigInteger); chat_id:Mapped[int]=mapped_column(BigInteger)
    role:Mapped[str]=mapped_column(String(20)); text:Mapped[str]=mapped_column(Text)
class Instruction(Base):
    __tablename__="instructions"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    owner_id:Mapped[int]=mapped_column(BigInteger); text:Mapped[str]=mapped_column(Text)
    expires:Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
class Business(Base):
    __tablename__="business"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    connection_id:Mapped[str]=mapped_column(String(255),unique=True); owner_id:Mapped[int]=mapped_column(BigInteger)
    enabled:Mapped[bool]=mapped_column(Boolean,default=True)
class Referral(Base):
    __tablename__="referrals"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    inviter:Mapped[int]=mapped_column(BigInteger); invited:Mapped[int]=mapped_column(BigInteger,unique=True); rewarded:Mapped[bool]=mapped_column(Boolean,default=False)
class RequiredChannel(Base):
    __tablename__="required_channels"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    chat_id:Mapped[int]=mapped_column(BigInteger,unique=True); username:Mapped[str|None]=mapped_column(String(255)); enabled:Mapped[bool]=mapped_column(Boolean,default=True)
class BioConfig(Base):
    __tablename__="bio_config"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    owner_id:Mapped[int]=mapped_column(BigInteger,unique=True); ad_text:Mapped[str]=mapped_column(String(140))
    enabled:Mapped[bool]=mapped_column(Boolean,default=True); original_bio:Mapped[str|None]=mapped_column(Text)
class Event(Base):
    __tablename__="events"; id:Mapped[int]=mapped_column(Integer,primary_key=True)
    owner_id:Mapped[int]=mapped_column(BigInteger); kind:Mapped[str]=mapped_column(String(80)); details:Mapped[str|None]=mapped_column(Text)
    created:Mapped[datetime]=mapped_column(DateTime(timezone=True),default=lambda:datetime.now(timezone.utc))

engine=create_async_engine(settings.DATABASE_URL)
Session=async_sessionmaker(engine,expire_on_commit=False)
async def init_db():
    async with engine.begin() as c: await c.run_sync(Base.metadata.create_all)
