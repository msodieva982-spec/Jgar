from database import Session,Admin,Permission,Feature,User
from sqlalchemy import select

PERMISSIONS={"ban","unban","pro_give","pro_remove","broadcast","stats","admin_add","admin_remove","permissions","features","channels","logs"}
async def allowed(tg_id,name):
    from config import settings
    if tg_id==settings.OWNER_ID:return True
    async with Session() as s:
        a=(await s.execute(select(Admin).where(Admin.tg_id==tg_id,Admin.active==True))).scalar_one_or_none()
        if not a:return False
        return (await s.execute(select(Permission).where(Permission.admin_id==a.id,Permission.name==name))).scalar_one_or_none() is not None
async def add(tg_id,names):
    async with Session() as s:
        a=(await s.execute(select(Admin).where(Admin.tg_id==tg_id))).scalar_one_or_none()
        if not a:a=Admin(tg_id=tg_id);s.add(a);await s.flush()
        for n in names:
            if n in PERMISSIONS:s.add(Permission(admin_id=a.id,name=n))
        await s.commit()
async def remove(tg_id):
    async with Session() as s:
        a=(await s.execute(select(Admin).where(Admin.tg_id==tg_id))).scalar_one_or_none()
        if a:a.active=False;await s.commit()
async def ban(tg_id,value=True):
    async with Session() as s:
        u=(await s.execute(select(User).where(User.tg_id==tg_id))).scalar_one_or_none()
        if u:u.banned=value;await s.commit()
async def feature(name,on):
    async with Session() as s:
        f=(await s.execute(select(Feature).where(Feature.name==name))).scalar_one_or_none()
        if not f:s.add(Feature(name=name,enabled=on))
        else:f.enabled=on
        await s.commit()
