import asyncio
from aiogram import Bot, Dispatcher
from config import settings
from database import init_db
from handlers import register_handlers
from scheduler import start_scheduler

async def main():
    await init_db()
    bot=Bot(settings.BOT_TOKEN)
    dp=Dispatcher()
    register_handlers(dp)
    await start_scheduler(bot)
    await dp.start_polling(bot, allowed_updates=["message","callback_query","business_connection","business_message","edited_business_message","deleted_business_messages","pre_checkout_query"])

if __name__=="__main__":
    asyncio.run(main())
