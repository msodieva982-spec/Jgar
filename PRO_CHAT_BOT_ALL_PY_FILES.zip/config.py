import os
from dotenv import load_dotenv
load_dotenv()

class Settings:
    BOT_TOKEN=os.getenv("BOT_TOKEN","")
    OPENAI_API_KEY=os.getenv("OPENAI_API_KEY","")
    OWNER_ID=int(os.getenv("OWNER_ID","0"))
    BOT_USERNAME=os.getenv("BOT_USERNAME","").lstrip("@")
    DATABASE_URL=os.getenv("DATABASE_URL","sqlite+aiosqlite:///./pro_chat_bot.db")
    AI_MODEL=os.getenv("AI_MODEL","gpt-5-mini")
    STT_MODEL=os.getenv("STT_MODEL","gpt-4o-mini-transcribe")
    REFERRALS_FOR_REWARD=int(os.getenv("REFERRALS_FOR_REWARD","3"))
    REFERRAL_REWARD_DAYS=int(os.getenv("REFERRAL_REWARD_DAYS","1"))
    BIO_AD_INTERVAL_MINUTES=int(os.getenv("BIO_AD_INTERVAL_MINUTES","10"))

settings=Settings()
if not settings.BOT_TOKEN: raise RuntimeError("BOT_TOKEN yo'q")
