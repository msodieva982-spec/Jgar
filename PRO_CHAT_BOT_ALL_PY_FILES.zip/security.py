import os
def secret_present(name):return bool(os.getenv(name))
def safe_text(text,max_len=4000):return (text or "")[:max_len]
