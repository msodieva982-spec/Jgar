from database import Session,Business,MessageLog,Event
from sqlalchemy import select
from ai import ask
from config import settings

async def connection(update):
    bc=update.business_connection
    async with Session() as s:
        x=(await s.execute(select(Business).where(Business.connection_id==bc.id))).scalar_one_or_none()
        if not x:s.add(Business(connection_id=bc.id,owner_id=bc.user.id,enabled=bc.is_enabled))
        else:x.enabled=bc.is_enabled
        await s.commit()

async def incoming(bot,m):
    async with Session() as s:
        x=(await s.execute(select(Business).where(Business.connection_id==m.business_connection_id,Business.enabled==True))).scalar_one_or_none()
        if not x:return
        text=m.text or m.caption or ""
        s.add(MessageLog(owner_id=x.owner_id,chat_id=m.chat.id,message_id=m.message_id,kind="message",text=text));await s.commit()
        if text:
            ans=await ask(x.owner_id,m.chat.id,text)
            await bot.send_message(chat_id=m.chat.id,text=ans,business_connection_id=m.business_connection_id)

async def edited(bot,m):
    async with Session() as s:
        x=(await s.execute(select(Business).where(Business.connection_id==m.business_connection_id))).scalar_one_or_none()
        if x:
            s.add(Event(owner_id=x.owner_id,kind="edited",details=f"message_id={m.message_id}"));await s.commit()
            await bot.send_message(chat_id=settings.OWNER_ID,text="✏️ Xabar tahrirlandi.")

async def deleted(bot,m):
    async with Session() as s:
        x=(await s.execute(select(Business).where(Business.connection_id==m.business_connection_id))).scalar_one_or_none()
        if x:
            s.add(Event(owner_id=x.owner_id,kind="deleted",details=str(m.message_ids)));await s.commit()
            await bot.send_message(chat_id=settings.OWNER_ID,text="🗑 Xabar o‘chirildi.")
