from database import Session,User,Event
from sqlalchemy import select,func
async def get():
    async with Session() as s:
        return {"users":(await s.execute(select(func.count(User.id)))).scalar_one(),
                "pro":(await s.execute(select(func.count(User.id)).where(User.pro_until!=None))).scalar_one(),
                "events":(await s.execute(select(func.count(Event.id)))).scalar_one()}
