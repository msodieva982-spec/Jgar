from database import Session,Feature
from sqlalchemy import select
async def enabled(name,default=True):
    async with Session() as s:
        x=(await s.execute(select(Feature).where(Feature.name==name))).scalar_one_or_none()
        return default if not x else x.enabled
async def toggle(name,value):
    async with Session() as s:
        x=(await s.execute(select(Feature).where(Feature.name==name))).scalar_one_or_none()
        if not x:s.add(Feature(name=name,enabled=value))
        else:x.enabled=value
        await s.commit()
