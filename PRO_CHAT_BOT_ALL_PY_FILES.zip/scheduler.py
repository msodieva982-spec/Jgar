import asyncio
from config import settings
from pro import active
from database import Session,Business,BioConfig
from sqlalchemy import select

async def start_scheduler(bot):
    asyncio.create_task(expiry_loop())
    asyncio.create_task(bio_loop(bot))

async def expiry_loop():
    from database import User
    from datetime import datetime,timezone
    while True:
        async with Session() as s:
            rows=(await s.execute(select(User).where(User.pro_until!=None,User.pro_until<=datetime.now(timezone.utc)))).scalars().all()
            # Expired PRO is represented by pro_until; no separate flag is needed.
            await s.commit()
        await asyncio.sleep(60)

async def bio_loop(bot):
    while True:
        async with Session() as s:
            rows=(await s.execute(select(Business).where(Business.enabled==True))).scalars().all()
        for b in rows:
            async with Session() as s:
                cfg=(await s.execute(select(BioConfig).where(BioConfig.owner_id==b.owner_id))).scalar_one_or_none()
            if cfg and cfg.enabled:
                try: await bot.set_business_account_bio(business_connection_id=b.connection_id,bio=cfg.ad_text[:140])
                except Exception: pass
        await asyncio.sleep(settings.BIO_AD_INTERVAL_MINUTES*60)
