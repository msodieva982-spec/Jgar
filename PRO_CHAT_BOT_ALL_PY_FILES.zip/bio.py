from database import Session,BioConfig
from sqlalchemy import select
from config import settings

async def set_ad(bot,connection_id,text=None):
    text=(text or f"🤖 Avto chat bot @{settings.BOT_USERNAME}")[:140]
    try:await bot.set_business_account_bio(business_connection_id=connection_id,bio=text)
    except Exception:return False
    return True
async def remove_ad(bot,connection_id,original=""):
    try:await bot.set_business_account_bio(business_connection_id=connection_id,bio=original[:140])
    except Exception:return False
    return True
