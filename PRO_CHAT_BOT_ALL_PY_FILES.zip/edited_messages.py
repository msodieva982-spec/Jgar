async def notify(bot,owner_id,message_id):
    await bot.send_message(owner_id,f"✏️ Xabar tahrirlandi: {message_id}")
