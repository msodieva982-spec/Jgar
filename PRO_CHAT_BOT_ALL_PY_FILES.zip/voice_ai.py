from ai import transcribe
async def voice_to_text(path):return await transcribe(path)
