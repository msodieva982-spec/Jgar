from database import Session,RequiredChannel
from sqlalchemy import select

async def check(bot,user_id):
    async with Session() as s: channels=(await s.execute(select(RequiredChannel).where(RequiredChannel.enabled==True))).scalars().all()
    for c in channels:
        try:
            m=await bot.get_chat_member(c.chat_id,user_id)
            if m.status in ("left","kicked"):return False
        except:return False
    return True
async def add(chat_id,username=None):
    async with Session() as s:s.add(RequiredChannel(chat_id=chat_id,username=username));await s.commit()
async def remove(chat_id):
    async with Session() as s:
        x=(await s.execute(select(RequiredChannel).where(RequiredChannel.chat_id==chat_id))).scalar_one_or_none()
        if x:x.enabled=False;await s.commit()
