from aiogram import Router,F
from aiogram.filters import Command,CommandStart
from aiogram.types import Message,Update
from ai import ask
from config import settings
from database import Session,User
from sqlalchemy import select
from business import connection,incoming,edited,deleted
from admin import allowed,ban,add,remove,feature
from pro import give,remove as remove_pro
from channels import check
from broadcast import send
from away import set_instruction
from referral import register

def register_handlers(dp):
    r=Router()
    @r.message(CommandStart())
    async def start(m:Message):
        arg=m.text.partition(" ")[2].strip()
        inv=int(arg[4:]) if arg.startswith("ref_") and arg[4:].isdigit() else None
        async with Session() as s:
            u=(await s.execute(select(User).where(User.tg_id==m.from_user.id))).scalar_one_or_none()
            if not u:
                u=User(tg_id=m.from_user.id,username=m.from_user.username,referral=f"ref_{m.from_user.id}",referred_by=inv);s.add(u);await s.commit()
        if inv:await register(inv,m.from_user.id)
        if not await check(m.bot,m.from_user.id):await m.answer("❌ Avval majburiy kanallarga obuna bo‘ling.");return
        await m.answer("🤖 PRO chat bot\n\nSavolingizni yozing.")

    @r.message(Command("away"))
    async def away(m):
        if m.from_user.id!=settings.OWNER_ID:return
        text=m.text.partition(" ")[2]
        await set_instruction(settings.OWNER_ID,text,24)
        await m.answer("✅ AI uchun 24 soatlik ko‘rsatma saqlandi.")

    @r.message(Command("ban"))
    async def b(m):
        if not await allowed(m.from_user.id,"ban"):await m.answer("❌ Sizga bu huquq berilmagan.");return
        await ban(int(m.text.split()[1]),True);await m.answer("✅ Ban.")

    @r.message(Command("unban"))
    async def ub(m):
        if not await allowed(m.from_user.id,"unban"):await m.answer("❌ Sizga bu huquq berilmagan.");return
        await ban(int(m.text.split()[1]),False);await m.answer("✅ Ban olib tashlandi.")

    @r.message(Command("pro"))
    async def p(m):
        if not await allowed(m.from_user.id,"pro_give"):await m.answer("❌ Sizga bu huquq berilmagan.");return
        a=m.text.split();await give(int(a[1]),int(a[2]));await m.answer("💎 PRO berildi.")

    @r.message(Command("removepro"))
    async def rp(m):
        if not await allowed(m.from_user.id,"pro_remove"):await m.answer("❌ Sizga bu huquq berilmagan.");return
        await remove_pro(int(m.text.split()[1]));await m.answer("✅ PRO qaytarib olindi.")

    @r.message(Command("addadmin"))
    async def aa(m):
        if not await allowed(m.from_user.id,"admin_add"):await m.answer("❌ Sizga bu huquq berilmagan.");return
        a=m.text.split();await add(int(a[1]),a[2].split(",") if len(a)>2 else []);await m.answer("✅ Admin qo‘shildi.")

    @r.message(Command("removeadmin"))
    async def ra(m):
        if not await allowed(m.from_user.id,"admin_remove"):await m.answer("❌ Sizga bu huquq berilmagan.");return
        await remove(int(m.text.split()[1]));await m.answer("✅ Admin olib tashlandi.")

    @r.message(Command("broadcast"))
    async def bc(m):
        if not await allowed(m.from_user.id,"broadcast"):await m.answer("❌ Sizga bu huquq berilmagan.");return
        ok,bad=await send(m.bot,m.text.partition(" ")[2]);await m.answer(f"✅ {ok}\n❌ {bad}")

    @r.message(F.text)
    async def text(m):
        if m.text.startswith("/"):return
        async with Session() as s:
            u=(await s.execute(select(User).where(User.tg_id==m.from_user.id))).scalar_one_or_none()
            if u and u.banned:return
        await m.answer(await ask(settings.OWNER_ID,m.chat.id,m.text))

    @dp.update.outer_middleware()
    async def business_middleware(handler,event,data):
        if isinstance(event,Update):
            if event.business_connection:await connection(event);return None
            if event.business_message:await incoming(mbot,event.business_message);return None
            if event.edited_business_message:await edited(mbot,event.edited_business_message);return None
            if event.deleted_business_messages:await deleted(mbot,event.deleted_business_messages);return None
        return await handler(event,data)

    global mbot
    async def setbot(bot): global mbot;mbot=bot
    # aiogram middleware registration above is kept simple; main injects bot via dp startup hook.
    dp.include_router(r)
