async def owner(bot,text,owner_id):
    try:await bot.send_message(owner_id,text)
    except Exception:pass
