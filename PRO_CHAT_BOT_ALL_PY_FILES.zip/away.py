from datetime import datetime,timezone,timedelta
from database import Session,Instruction
from sqlalchemy import select

async def set_instruction(owner_id,text,hours):
    async with Session() as s:
        s.add(Instruction(owner_id=owner_id,text=text,expires=datetime.now(timezone.utc)+timedelta(hours=hours)));await s.commit()
async def get_instruction(owner_id):
    async with Session() as s:
        x=(await s.execute(select(Instruction).where(Instruction.owner_id==owner_id).order_by(Instruction.id.desc()))).scalars().first()
        return x.text if x and (x.expires is None or x.expires>datetime.now(timezone.utc)) else ""
