from database import Session,MessageLog
async def record(owner_id,chat_id,message_id,kind,text=""):
    async with Session() as s:s.add(MessageLog(owner_id=owner_id,chat_id=chat_id,message_id=message_id,kind=kind,text=text));await s.commit()
