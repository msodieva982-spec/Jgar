from database import Session,Referral,User
from sqlalchemy import select,func
from config import settings
from pro import give

async def register(inviter,invited):
    if inviter==invited:return False
    async with Session() as s:
        old=(await s.execute(select(Referral).where(Referral.invited==invited))).scalar_one_or_none()
        if old:return False
        s.add(Referral(inviter=inviter,invited=invited));await s.commit()
    async with Session() as s:
        n=(await s.execute(select(func.count(Referral.id)).where(Referral.inviter==inviter,Referral.rewarded==False))).scalar_one()
        if n>=settings.REFERRALS_FOR_REWARD:
            rows=(await s.execute(select(Referral).where(Referral.inviter==inviter,Referral.rewarded==False).limit(settings.REFERRALS_FOR_REWARD))).scalars().all()
            for r in rows:r.rewarded=True
            await s.commit()
            await give(inviter,settings.REFERRAL_REWARD_DAYS)
            return True
    return False
