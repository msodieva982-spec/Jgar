from pro import give
async def payment_confirmed(user_id,days,payment_id):
    # Provider/webhook must verify payment before calling this.
    return await give(user_id,days)
