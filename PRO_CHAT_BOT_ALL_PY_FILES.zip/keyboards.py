from aiogram.types import InlineKeyboardMarkup,InlineKeyboardButton
def main():return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="💎 PRO",callback_data="pro")],[InlineKeyboardButton(text="📊 Statistika",callback_data="stats")]])
def admin():return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🚫 Ban",callback_data="ban")],[InlineKeyboardButton(text="💎 PRO",callback_data="pro")],[InlineKeyboardButton(text="📢 Broadcast",callback_data="broadcast")]])
