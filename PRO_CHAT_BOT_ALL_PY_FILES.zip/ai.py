from openai import AsyncOpenAI
from config import settings
from database import Session,ChatMemory
from sqlalchemy import select

client=AsyncOpenAI(api_key=settings.OPENAI_API_KEY) if settings.OPENAI_API_KEY else None
SYSTEM="""Sen PRO chat botning AI yordamchisisan. Egani o'zini deb ko'rsatma. Egasi bergan vaqtinchalik ko'rsatmalarga amal qil. Bilmagan ma'lumotni uydirma. Suhbatni tabiiy olib bor."""

async def ask(owner_id,chat_id,text):
    if not client:return "OPENAI_API_KEY sozlanmagan."
    async with Session() as s:
        rows=(await s.execute(select(ChatMemory).where(ChatMemory.owner_id==owner_id,ChatMemory.chat_id==chat_id).order_by(ChatMemory.id.desc()).limit(20))).scalars().all()
        msgs=[{"role":"system","content":SYSTEM}]+[{"role":x.role,"content":x.text} for x in reversed(rows)]+[{"role":"user","content":text}]
        r=await client.chat.completions.create(model=settings.AI_MODEL,messages=msgs)
        ans=r.choices[0].message.content or "Javob yo'q."
        s.add(ChatMemory(owner_id=owner_id,chat_id=chat_id,role="user",text=text));s.add(ChatMemory(owner_id=owner_id,chat_id=chat_id,role="assistant",text=ans));await s.commit()
        return ans

async def transcribe(path):
    if not client:return ""
    with open(path,"rb") as f:r=await client.audio.transcriptions.create(model=settings.STT_MODEL,file=f)
    return getattr(r,"text","")
