from database import Session,User
from sqlalchemy import select

async def send(bot,text):
    async with Session() as s: users=(await s.execute(select(User).where(User.banned==False))).scalars().all()
    ok=bad=0
    for u in users:
        try:await bot.send_message(u.tg_id,text);ok+=1
        except Exception:bad+=1
    return ok,bad
