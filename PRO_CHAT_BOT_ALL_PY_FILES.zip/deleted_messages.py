async def notify(bot,owner_id,message_ids):
    await bot.send_message(owner_id,"🗑 Xabar o‘chirildi: "+", ".join(map(str,message_ids)))
