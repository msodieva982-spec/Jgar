from payments import payment_confirmed
async def confirm_verified_payment(user_id,days,payment_id):return await payment_confirmed(user_id,days,payment_id)
