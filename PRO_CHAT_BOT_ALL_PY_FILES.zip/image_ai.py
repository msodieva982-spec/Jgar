from openai import AsyncOpenAI
from config import settings
client=AsyncOpenAI(api_key=settings.OPENAI_API_KEY) if settings.OPENAI_API_KEY else None
async def describe(url,question="Rasmni tahlil qil."):
    if not client:return "OPENAI_API_KEY sozlanmagan."
    r=await client.chat.completions.create(model=settings.AI_MODEL,messages=[{"role":"user","content":[{"type":"text","text":question},{"type":"image_url","image_url":{"url":url}}]}])
    return r.choices[0].message.content or ""
