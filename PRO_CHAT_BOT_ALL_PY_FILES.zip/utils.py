from datetime import datetime,timezone
def now():return datetime.now(timezone.utc)
def mention(user_id):return f"[user](tg://user?id={user_id})"
