from datetime import datetime,timezone,timedelta
from database import Session,User
from sqlalchemy import select

async def give(tg_id,days):
    async with Session() as s:
        u=(await s.execute(select(User).where(User.tg_id==tg_id))).scalar_one_or_none()
        if not u:return False
        now=datetime.now(timezone.utc);u.pro_until=max(u.pro_until or now,now)+timedelta(days=days);await s.commit();return True
async def remove(tg_id):
    async with Session() as s:
        u=(await s.execute(select(User).where(User.tg_id==tg_id))).scalar_one_or_none()
        if not u:return False
        u.pro_until=None;await s.commit();return True
async def active(tg_id):
    async with Session() as s:
        u=(await s.execute(select(User).where(User.tg_id==tg_id))).scalar_one_or_none()
        return bool(u and u.pro_until and u.pro_until>datetime.now(timezone.utc))
